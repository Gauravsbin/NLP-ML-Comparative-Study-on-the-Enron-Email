# Draft insert for G19_V4_revised: additional corpora and sequence models

All numbers come from `run.py` (seed 42, single run, hold-out evaluation; 95% bootstrap CIs use 500 resamples of the test messages and are in `results.csv`). Positive class = phishing. TF-IDF settings and hyper-parameters are those of Table 5.

## 3.12 Sequence models (new)

Three token-sequence models are added to the five learners and two ensembles. Tokens are the cleaned tokens of Section 3.3, truncated to the first 80 per message, with a vocabulary of the 1,500 most frequent training tokens plus UNK.

**HMM (class-conditional).** One discrete hidden Markov model per class (K = 4 hidden states, multinomial emissions), trained by Baum-Welch (15 iterations, scaled forward-backward, implemented in NumPy). A message is assigned to the class with the higher log-likelihood plus log prior.

**MEMM.** A maximum-entropy Markov model over two states (legitimate, phishing). The local distribution P(s_t | s_{t-1}, o_t, o_{t-1}) is a logistic model on the current token, previous token and previous state, and a message is labelled by Viterbi decoding. Because every token in a message carries the message label, training with the gold previous state lets the model learn to copy the previous state (the label-bias problem). We therefore report two variants: *strict* (gold previous state) and *noise 0.3* (previous state replaced by a random state with probability 0.3 during training).

**Markov chain.** A class-conditional bigram language model with add-0.1 smoothing, the observable-state counterpart of the HMM.

HMM and MEMM were designed for sequence labelling. Here they are used for whole-message classification, which is not their natural task, so the results below are a comparison of model families and not a claim that they suit phishing detection.

## 4.8 Additional corpora and cross-corpus evaluation (new)

### Corpora

| Corpus | Messages | Class balance | Notes |
|---|---|---|---|
| ferb | 9,480 | 4,708 phishing / 4,772 legitimate | Synthetic-looking, LLM-style English correspondence addressed to one organisation; 777 sender domains, 735 of them only in the phishing class |
| Synthetic short-text set | 2,000 | 1,000 / 1,000 | After cleaning only 93 distinct texts remain; 1,900 messages are duplicates of another |

Two further uploads could not be used: the Poland archive contains password-protected `.pkl` files plus a 7-row teaser whose only label column (`cluster_gt`) appears to be a campaign-cluster ID, not a phishing/legitimate label; the archive `18471483.zip` was empty (0 bytes). The Netherland and Portugal archives contain the same file (`Phishing_validation_emails.csv`, byte-identical).

### Audit results

- ferb has no near-duplicates (0.0% of random test messages above cosine 0.9), so unlike Enron the random split is not inflated by duplicates. Grouping by normalised subject (5,483 distinct subjects in 9,480 messages) changed nothing: 0 training messages were removed.
- ferb is nonetheless separable by a single feature. Subject-only F1 = 0.999, body-only F1 = 1.000, sender-domain-only F1 = 0.981. The first cleaned token is "urgent" in 4,703 of 4,708 phishing messages, while legitimate messages start with "data" (3,353) or "confirmation" (872). 77% of phishing subjects begin with "Urgent:".
- The six-term keyword rule of Section 3.10 reaches only F1 = 0.65 on ferb but 0.83 on the synthetic set, so the label provenance differs between corpora.
- The synthetic set is fully duplicated: its random test messages all have a near-duplicate in training (100%).

### Results (F1, positive class; AUC in brackets where it adds information)

| Model | ferb random | ferb grouped | ferb -> synthetic | synthetic random | synthetic grouped | synthetic -> ferb |
|---|---|---|---|---|---|---|
| Logistic Regression | 1.000 | 0.999 | 0.689 (0.71) | 1.000 | 1.000 | 0.491 (0.61) |
| Multinomial NB | 1.000 | 0.999 | 0.713 (0.67) | 1.000 | 1.000 | 0.563 (0.58) |
| Linear SVM | 1.000 | 0.999 | 0.689 (0.63) | 1.000 | 1.000 | 0.477 (0.59) |
| Random Forest | 1.000 | 0.999 | 0.000 (0.49) | 1.000 | 1.000 | 0.293 (0.62) |
| Gradient Boosting | 0.999 | 0.999 | 0.000 (0.50) | 1.000 | 0.186 (1.00) | 0.360 (0.76) |
| Vote-5 | 1.000 | 0.999 | 0.713 (0.66) | 1.000 | 1.000 | 0.482 (0.62) |
| Vote-4 | 1.000 | 0.999 | 0.647 (0.67) | 1.000 | 1.000 | 0.425 (0.63) |
| HMM (K = 4) | 0.999 | 0.999 | 0.693 (0.67) | 1.000 | 1.000 | 0.490 (0.49) |
| MEMM, noise 0.3 | 0.914 | 0.920 | 0.713 (0.65) | 1.000 | 1.000 | 0.323 (0.41) |
| MEMM, strict | 1.000 | 0.999 | 0.000 (0.71) | 0.858 | 0.847 | 0.664 (0.75) |
| Markov chain (bigram) | 1.000 | 0.999 | 0.713 (0.56) | 1.000 | 0.186 (1.00) | 0.594 (0.67) |
| Keyword rule (6 terms) | 0.654 | 0.608 | 0.806 | 0.830 | 1.000 | 0.647 |

Test sizes: ferb random 1,896; ferb grouped 2,135 (7,345 training); synthetic random 400; synthetic grouped 370 (1,630 training); cross-corpus tests use the whole other corpus.

### Findings

1. **In-corpus scores are saturated and uninformative.** On ferb every model except the noise-trained MEMM reaches F1 of at least 0.999, and the sequence models (HMM, Markov chain) match the five learners. This is explained by the first-token shortcut above: a model that reads the opening words already separates the classes. It also explains why the strict MEMM, which effectively decides from the first token and copies the state, scores 1.000 here.
2. **Accuracy does not transfer.** Moving from ferb to the synthetic set or back drops F1 to 0.00-0.71 and AUC to 0.41-0.76, close to chance for most models. Several models predict one class for everything (recall 1.0 with precision 0.525, or F1 = 0.000), which indicates threshold miscalibration under domain shift. Ranking quality also collapses in some cases (Random Forest and Gradient Boosting AUC 0.49-0.50 on ferb -> synthetic), but not in all (Gradient Boosting AUC 0.76 on synthetic -> ferb).
3. **The sequence models offer no advantage.** The HMM and Markov chain equal the classical models in-corpus and are not better across corpora (HMM AUC 0.49 on synthetic -> ferb). The MEMM is the least stable: the noise variant loses 8 F1 points on ferb, and the strict variant is perfect on ferb but fails on the synthetic set (F1 0.858 random, 0.000 cross-corpus), consistent with label bias.
4. **A keyword rule beats every learned model across corpora in one direction.** ferb -> synthetic: keyword rule F1 0.806 versus at most 0.713 for the learners.
5. **Calibration matters for sequence scores.** On the synthetic grouped split, Gradient Boosting and the Markov chain have AUC 1.00 but F1 0.186, so their fixed thresholds (0.5 and 0) are wrong after the distribution changes.

### Limits of this section

- One seed and one hold-out split per protocol. The CIs in `results.csv` are bootstrap intervals (500 resamples) over test messages, so they do not capture split-to-split variance; repeated grouped cross-validation was not run.
- The Enron corpus of the main paper was not among the uploads, so no Enron -> other-corpus or other-corpus -> Enron transfer was run. Both new corpora look synthetic, so they are weak stand-ins for verified phishing corpora (Nazario, SpamAssassin, CSDMC).
- HMM states K = 4 was not tuned. The MEMM uses one-hot current-token and previous-token features over the 1,500-token vocabulary and is trained with SGD.
- Only the first 80 tokens are modelled, which favours the first-token shortcut in ferb.

## Suggested edits to the paper

- Add 3.12 above and 4.8 as a new subsection, plus RQ6: "Do sequence models (HMM, MEMM, Markov chain) and cross-corpus transfer change the conclusions?"
- Add one sentence to the Abstract and Conclusions: random-split and in-corpus scores on two additional corpora are saturated (F1 >= 0.999) while cross-corpus F1 falls to 0.00-0.71.
- Move the sentence "no transformer or recurrent baseline" in Section 4.7 to say the sequence models HMM, MEMM and Markov chain were added, and that a transformer baseline remains outstanding.
- Describe ferb and the synthetic set as synthetic corpora with template-level shortcuts, not as verified phishing data.
